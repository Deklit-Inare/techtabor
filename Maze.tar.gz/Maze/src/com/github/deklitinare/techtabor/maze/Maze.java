package com.github.deklitinare.techtabor.maze;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;

public class Maze {

	private boolean[][] cells;
	public int width;
	public int height;

	public void fill(boolean fill) {

		cells = new boolean[width][height];
		for (int i = 0; i < width; i++) {

			for (int j = 0; j < height; j++) {

				cells[i][j] = new Boolean(fill);

			}

		}

	}

	public BufferedImage printOnPicture(int border, int pixelSize) throws IOException {

		int imgWidth = width * pixelSize + 2 * border;
		int imgHeight = height * pixelSize + 2 * border;

		BufferedImage img = new BufferedImage(imgWidth, imgHeight, BufferedImage.TYPE_BYTE_BINARY);

		img.getGraphics().fillRect(0, 0, imgWidth, border);
		img.getGraphics().fillRect(0, 0, border, imgHeight);
		img.getGraphics().fillRect(imgWidth-border, 0, border, imgHeight);
		img.getGraphics().fillRect(0, imgHeight-border, imgWidth, border);
		
		
		for (int i = 0; i < width; i++) {

			for (int j = 0; j < height; j++) {
				int x = border + i * pixelSize;
				int y = border + j * pixelSize;
				//if (!cells[i][j])
			//	System.out.println(x + "; " + y);
				
				img.setRGB(x, y, Color.RED.getRGB());
				if(!cells[i][j])img.getGraphics().fillRect(x, y, pixelSize, pixelSize);

			}

		}

	//	ImageIO.write(img, "png", new File("/iwn/linux/java/MazeRunner/test/" + System.currentTimeMillis() + ".png"));
		return img;
	}

	public void print() {

		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				System.out.print(cells[i][j] ? " " : "X");
			}
			System.out.println();
		}

	}

	public Maze(int width, int height, boolean fill) {

		this.width = width;
		this.height = height;

		// cells = new boolean[width][height];

		fill(fill);

	}

	public boolean isEmpty(int X, int Y) {

		if (X >= 0 && Y >= 0 && X < width && Y < height) {
			return cells[X][Y];
			// return true;
		} else
			return false;

	}

	public boolean isWall(int X, int Y) {

		return !isEmpty(X, Y);

	}

	public void setEmpty(int x, int y) {

		cells[x][y] = true;

	}

	public void setWall(int x, int y) {

		cells[x][y] = false;

	}

}
