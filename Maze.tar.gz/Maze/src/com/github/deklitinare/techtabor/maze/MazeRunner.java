package com.github.deklitinare.techtabor.maze;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MazeRunner {

	public MazeRunner(int x, int y, Maze maze) {

		this.x = x;
		this.y = y;
		this.maze = maze;

	}

	private int x;
	private int y;
	private Maze maze;

	public boolean getRelativeEmpty(int x, int y) {

		int fX = this.x + x;
		int fY = this.y + y;

		// System.out.println("Relative emptiness is being observed at (" +
		// this.x + "; " + this.y + "), seeing if (" + fX
		// + "; " + fY + ") is an empty cell.");
		boolean out = maze.isEmpty(fX, fY);

		// System.out.println("\t\t\tResult: " + (out ? "Empty" : "Wall"));

		return out;

	}

	public boolean getRelativeWall(int x, int y) {
		return !getRelativeWall(x, y);
	}

	public boolean run(Random rnd) {
		boolean modify;
		if (maze.isWall(x, y)) {

			List<String> routes = new ArrayList<String>();
			routes.clear();

			boolean left = true;
			for (int i = -2; i <= -1; i++) {
				for (int j = -1; j <= 1; j++) {
					left = left && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> left=" + left);
				}
			}
			if (left)
				routes.add("left");

			boolean right = true;
			for (int i = 1; i <= 2; i++) {
				for (int j = -1; j <= 1; j++) {
					right = right && getRelativeEmpty(i, j);
				}
			}
			if (right)
				routes.add("right");

			boolean up = true;
			for (int i = -1; i <= 1; i++) {
				for (int j = -2; j <= -1; j++) {
					up = up && getRelativeEmpty(i, j);
				}
			}
			if (up)
				routes.add("up");

			boolean down = true;
			for (int i = -1; i <= 1; i++) {
				for (int j = 1; j <= 2; j++) {
					down = down && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> up=" + up);
				}
			}
			if (down)
				routes.add("down");

			if (routes.size() > 0) {
				String way = routes.get(rnd.nextInt(routes.size()));
				/*
				 * System.out.println("Routes available: " + routes.size());
				 * 
				 * for (int i = 0; i < routes.size(); i++) {
				 * System.out.print(routes.get(i) + ", "); }
				 * 
				 * System.out.println("\n" + way + "\tx:" + x + "\ty:" + y);
				 */
				switch (way) {

				case "up":

					y--;

					break;

				case "down":

					y++;

					break;

				case "left":

					x--;

					break;

				case "right":

					x++;

					break;

				}

				maze.setWall(x, y);
				modify = true;
			} else {

				// System.out.println("Empty set of available routes.");
				modify = false;
			}

		} else {
			if (legalPos()) {
				maze.setWall(x, y);
				modify = true;
			} else
				modify = false;
		}

		return modify;

	}

	public boolean run2(Random rnd) {
		boolean modify;
		if (maze.isWall(x, y)) {

			List<String> routes = new ArrayList<String>();
			routes.clear();

			boolean uleft = true;
			for (int i = -2; i <= 0; i++) {
				for (int j = 0; j <= 2; j++) {
					if (i != 0 || j != 0)
						uleft = uleft && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> left=" + left);
				}
			}
			if (uleft)
				routes.add("uleft");

			boolean uright = true;
			for (int i = 0; i <= 2; i++) {
				for (int j = 0; j <= 2; j++) {
					if (i != 0 || j != 0)
						uright = uright && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> left=" + left);
				}
			}
			if (uright)
				routes.add("uright");

			boolean dright = true;
			for (int i = 0; i <= 2; i++) {
				for (int j = -2; j <= 0; j++) {
					if (i != 0 || j != 0)
						dright = dright && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> left=" + left);
				}
			}
			if (dright)
				routes.add("dright");

			boolean dleft = true;
			for (int i = -2; i <= 0; i++) {
				for (int j = -2; j <= 0; j++) {
					if (i != 0 || j != 0)
						dleft = dleft && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> left=" + left);
				}
			}
			if (dleft)
				routes.add("dleft");

			boolean left = true;
			for (int i = -2; i <= -1; i++) {
				for (int j = -1; j <= 1; j++) {
					left = left && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> left=" + left);
				}
			}
			if (left)
				routes.add("left");

			boolean right = true;
			for (int i = 1; i <= 2; i++) {
				for (int j = -1; j <= 1; j++) {
					right = right && getRelativeEmpty(i, j);
				}
			}
			if (right)
				routes.add("right");

			boolean up = true;
			for (int i = -1; i <= 1; i++) {
				for (int j = -2; j <= -1; j++) {
					up = up && getRelativeEmpty(i, j);
				}
			}
			if (up)
				routes.add("up");

			boolean down = true;
			for (int i = -1; i <= 1; i++) {
				for (int j = 1; j <= 2; j++) {
					down = down && getRelativeEmpty(i, j);
					// System.out.println(" >> DEBUG >> up=" + up);
				}
			}
			if (down)
				routes.add("down");

			if (routes.size() > 0) {
				String way = routes.get(rnd.nextInt(routes.size()));
				/*
				 * System.out.println("Routes available: " + routes.size());
				 * 
				 * for (int i = 0; i < routes.size(); i++) {
				 * System.out.print(routes.get(i) + ", "); }
				 * 
				 * System.out.println("\n" + way + "\tx:" + x + "\ty:" + y);
				 */
				switch (way) {

				case "up":

					y--;

					break;

				case "down":

					y++;

					break;

				case "left":

					x--;

					break;

				case "right":

					x++;

					break;

				case "uleft":

					x--;
					y--;

					break;

				case "uright":

					x++;
					y--;

					break;

				case "dleft":

					x--;
					y++;

					break;

				case "dright":

					x++;
					y++;

					break;

				}

				maze.setWall(x, y);
				modify = true;
			} else {

				// System.out.println("Empty set of available routes.");
				modify = false;
			}

		} else {
			if (legalPos()) {
				maze.setWall(x, y);
				modify = true;
			} else
				modify = false;
		}

		return modify;

	}

	public boolean legalPos() {
		boolean legal = true;
		for (int i = -1; i <= 1; i++) {

			for (int j = -1; j <= 1; j++) {

				if (i != 0 || j != 0) {
					legal = legal && getRelativeEmpty(i, j);
				}

			}

		}

		return legal;

	}

}
