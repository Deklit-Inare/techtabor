package com.github.deklitinare.techtabor.maze;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

public class MazeMain {

	public static void main(String[] args) {

		for (int i = 0; i < 1000; i++) {
			automatic(i);
		}

	}

	private static void automatic(int current) {
		File dir = new File("/iwn/linux/java/MazeRunner/automatic/" + System.currentTimeMillis());
		dir.mkdirs();

		Maze maze = new Maze(100, 100, true);
		MazeRunner runner = new MazeRunner(maze.width / 2, maze.height / 2, maze);
		Random rnd = new Random();
		long start = 0;
		for (int i = 0; i < 2000; i++) {
			if (i > 0)
				System.out.println("IC: " + i + " OC: " + current);
			start = System.nanoTime();
			while (runner.run(rnd)) {

				/*	*/ File outPic = new File(dir, System.currentTimeMillis() + ".png");
				try {

					ImageIO.write(maze.printOnPicture(12, 4), "png", outPic);

				} catch (IOException e) {

					e.printStackTrace();

				}
				/*		*/
			}
			int newX;
			int newY;
			do {

				newX = rnd.nextInt(maze.width);
				newY = rnd.nextInt(maze.height);

			} while (maze.isEmpty(newX, newY));

			runner = new MazeRunner(newX, newY, maze);

		}

		try {
			ImageIO.write(maze.printOnPicture(12, 4), "png", new File(dir, "test3.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void oldmain() {
		double n = 0;
		double score = 0;

		double doubleAvg = 0;
		double doubleAvgN = 0;

		int max = 0;

		while (true) {

			for (int i = 0; i < 1000; i++) {
				int bMax = new Integer(max);
				Object[] res = genMaze(true);
				int curr = (int) (res[1]);
				n++;
				score += curr;
				max = Math.max(curr, max);

				if (bMax != max) {

					try {
						((Maze) res[0]).printOnPicture(64, 4);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			}
			doubleAvg += score / n;
			doubleAvgN++;
			System.out.println(doubleAvg / doubleAvgN + "\t\tMax: " + max);

		}
	}

	private static Object[] genMaze(boolean save) {
		int n;
		Maze maze = new Maze(1000, 1000, true);
		MazeRunner runner = new MazeRunner(1, 1, maze);
		Random rnd = new Random();
		// maze.print();
		while (true) {

			maze = new Maze(1000, 1000, true);
			runner = new MazeRunner(maze.width / 2, maze.height / 2, maze);
			n = 0;
			rnd = new Random();
			while (runner.run(rnd))
				n++;
			// if(n>0)System.out.println(n);

			if (n > 0) {
				// System.out.println(n);
				break;
			}
		}

		while (true) {

			// maze = new Maze(1000, 1000, true);
			runner = new MazeRunner(maze.width / 2, maze.height / 2, maze);
			n = 0;
			rnd = new Random();
			while (runner.run(rnd))
				n++;
			// if(n>0)System.out.println(n);

			if (n > 0) {
				// System.out.println(n);
				break;
			}
		}
		// maze.print();
		if (save) {
			try {
				maze.printOnPicture(64, 4);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return new Object[] { maze, n };
	}

}
