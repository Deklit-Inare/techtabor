package com.github.deklitinare.techtabor.secpaint;


public class Circle {
	
	private double radius;
	
	private Coordinates getPoint(double x, double y) {
		
		double alpha = x/180*Math.PI;
		double c = radius + y;
		
		double X = c*Math.cos(alpha);
		double Y = c*Math.sin(alpha);
		
		return new Coordinates(X, Y);
		
	}
	
}
