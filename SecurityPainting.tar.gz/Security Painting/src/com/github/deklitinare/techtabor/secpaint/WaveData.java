package com.github.deklitinare.techtabor.secpaint;

public class WaveData {
	
	public double min;
	public double max;
	public double freq;
	public double phOff;
	
	public WaveData(double minimum, double maximum, double frequency, double phaseOffset) {
		
		min = minimum;
		max = maximum;
		freq = frequency;
		phOff = phaseOffset;
		
	}
	
	public static double xsin(double x) {
		
		return (Math.sin(x)+1d)/2d;
		
	}
	
	public double getVal(double x) {
		
		return min + (max - min) * (freq*x+phOff);
		
	}
	
}
