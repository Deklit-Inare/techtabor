package com.github.deklitinare.techtabor.secpaint;

public class SecurityPaintingMain {

	public static void main(String[] args) {
		
		WaveData wi, wm, wo;
		
		int repeat = 1;
		
		
		
	}

}
