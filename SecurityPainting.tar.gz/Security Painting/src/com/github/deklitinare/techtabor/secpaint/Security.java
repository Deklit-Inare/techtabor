package com.github.deklitinare.techtabor.secpaint;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Security {

	public static void white(int x, int y) {
		img.setRGB(x, y, Color.white.getRGB());
	}
	
	public static void white(double x, double y) {
		white((int)x,(int)y);
	}

	public static void circle(int x, int y, double radius) {
/*
		for (int i = 0; i <= 360; i += 2) {
			int nX = (int) (radius * SecurityPainting.sin(i) + x);
			int nY = (int) (radius * SecurityPainting.cos(i) + y);
			white(nX, nY);
		}
*/		
		for(double i = -1; i <= 1; i+=0.05) {
			for(double j = -1; j <= 1; j+=0.05) {
				if(Math.abs(i*i+j*j) <= 1) {
					white(x + i * radius, y + j * radius);
				}
			}
		}

	}

	static BufferedImage img;

	public static void main(String[] args) {

		double mult = 4;

		int size = (int) (2048 * mult);

		double minInner = .23;
		double maxInner = .75;
		double minOuter = .8;
		double maxOuter = .0d;

		WaveData inner = new WaveData(minInner * (double) size / 2, maxInner * (double) size / 2, 3, -90);
		WaveData outer = new WaveData(minOuter * (double) size / 2, maxOuter * (double) size / 2, 5, -90);

		SecurityPainting painting = new SecurityPainting(inner, outer);

		img = new BufferedImage(size, size, BufferedImage.TYPE_BYTE_BINARY);
		/*
		 * try { img = ImageIO.read(new
		 * File("/iwn/linux/java/CardSecurityPainting/test/1503712141684.png"));
		 * } catch (IOException e1) { e1.printStackTrace(); System.exit(-1); }
		 */
		for (double i = 0; i < 360 * SecurityPainting.offsMult; i += 0.02) {

			Coordinates c = painting.getCoordinates(i);

			int finX = (int) c.x() + size / 2;
			int finY = (int) c.y() + size / 2;
			try {
				// img.setRGB(finX, finY, Color.white.getRGB());
				circle(finX, finY, mult);
				circle(finX, finY, mult*2);
				circle(finX, finY, mult*3);
			} catch (Exception e) {
			}
		}

		try {
			ImageIO.write(img, "png",
					new File("/iwn/linux/java/CardSecurityPainting/test/" + System.currentTimeMillis() + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}

	}

	private static void makeimageidk() {
		int width = 1024 * 4;
		int height = 768 * 4;

		double wmult = width / 1024;
		double hmult = height / 256;

		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_BINARY);

		double multX = 0.03 / wmult;
		double multY = 20 * hmult;

		double multInsideX = 0.01;

		Color BacgroundColor = Color.white;
		Color LineColor = Color.black;

		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				img.setRGB(i, j, BacgroundColor.getRGB());
			}
		}

		for (double i = -width / 2; i < width / 2; i += 0.001) {

			// System.out.println(i + "\t" + get(i));

			int[] c = circle(get(i / 180 * Math.PI), i / 180 * Math.PI, width, height);

			int xFin = c[0];
			int yFin = c[1];

			/*
			 * int xFin = (int) (i%(Math.PI*2*64) + width / 2); int yFin = (int)
			 * (get((i)*multX)*multY + height/2);
			 */
			// System.out.println(xFin + " " + yFin);

			if (xFin < width && xFin >= 0 && yFin < height && yFin >= 0) {
				img.setRGB(xFin, yFin, LineColor.getRGB());
			}

		}

		File out = new File("/iwn/linux/java/CardSecurityPainting/test/" + System.currentTimeMillis() + ".png");
		try {
			ImageIO.write(img, "png", out);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public static int[] circle(double result, double angle, int width, int height) {

		double x = result * Math.sin(angle);
		double y = result * Math.cos(angle);

		int xFin = (int) (width / 2 - x * 50 * 4);
		int yFin = (int) (height / 2 - y * 50 * 4);

		return new int[] { xFin, yFin };

	}

	public static double sin(double x) {

		return (x % 1) * 100 + Math.sin(x);

	}

	public static double get(double x) {

		double downParts = 12;
		double upParts = 6;

		double midParts = 20;
		double midDelayTo = 15;

		double downDelay = -Math.PI / 2;
		double upDelay = Math.PI / 2;

		double downMin = 3;
		double upMin = 5;

		double downMult = 0.2;
		double upMult = 1;

		double waveDown = downMin + sin(downDelay + x * downParts * 2d) * downMult;
		double waveUp = upMin + sin(upDelay + x * upParts * 2d) * upMult;

		double waveMid = (sin(x * midParts * 2d + Math.PI * 2 / midDelayTo * x) + 1) / 2;

		double waveFinal = waveDown + waveMid * (waveUp - waveDown);

		return waveFinal;

	}

}
