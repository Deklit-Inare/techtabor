package com.github.deklitinare.techtabor.secpaint;

public class Coordinates {
	
	public Coordinates(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public double x() {
		return x;
	}
	
	public double y() {
		return y;
	}
	
	private double x;
	private double y;
	
}
