package com.github.deklitinare.techtabor.secpaint;

public class SecurityPainting {
	
	public SecurityPainting(WaveData inner, WaveData outer) {
		this.inner = inner;
		this.outer = outer;
	}
	
	public WaveData inner;
	public WaveData outer;
	
	public double func(double x, WaveData wd) {
		
		return wd.min + sin(wd.freq * x + wd.phOff) * (wd.max - wd.min);
		
	}
	
	public static double offsMult = 16;
	
	public double funcMID(double x) {
		
		return sin(x*2 + x/360*(360/offsMult));
		
	}
	
	public Coordinates getCoordinates(double x) {
		
		double in = func(x, inner);
		double out = func(x, outer);
		
		double y = in + funcMID(x) * (out - in);
		return new Coordinates(
				y*(sin(x)*2-1),
				y*(cos(x)*2-1)
				);
		
	}
	
	public static double sin(double x) {
		return (Math.sin(x/180*Math.PI)+1)/2;
	}
	
	public static double cos(double x) {
		return sin(x+90);
	}
	
}
